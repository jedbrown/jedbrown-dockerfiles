#ifndef MIXED_LANG_HPP
#define MIXED_LANG_HPP

#include <string>

namespace tribits_mixed {

std::string mixedLang();

}

#endif // MIXED_LANG_HPP

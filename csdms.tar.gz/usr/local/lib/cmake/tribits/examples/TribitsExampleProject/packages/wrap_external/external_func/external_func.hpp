#ifndef EXTERANL_PROJ_EXTERNAL_FUNC_HPP
#define EXTERANL_PROJ_EXTERNAL_FUNC_HPP

#include <string>

namespace ExternalProj {

std::string external_func();

} // namespace ExternalProj

#endif /* EXTERANL_PROJ_EXTERNAL_FUNC_HPP */

#!/usr/bin/python3
if __name__ == '__main__':
  import sys
  import os
  sys.path.insert(0, os.path.abspath('config'))
  import configure
  configure_options = [
    '--download-cgns',
    '--download-cmake',
    '--download-ctetgen',
    '--download-hdf5',
    '--download-hypre',
    '--download-metis',
    '--download-ml',
    '--download-mumps',
    '--download-parmetis',
    '--download-scalapack',
    '--download-suitesparse',
    '--download-superlu',
    '--download-superlu_dist',
    '--download-triangle',
    '--prefix=/usr/local',
    '--with-debugging=0',
    '--with-zlib',
    'COPTFLAGS=-O2 -march=haswell -ffp-contract=fast',
    'CXXOPTFLAGS=-O2 -march=haswell -ffp-contract=fast',
    'FOPTFLAGS=-O2 -march=haswell -ffp-contract=fast',
    'PETSC_ARCH=arch-linux-c-opt',
  ]
  configure.petsc_configure(configure_options)

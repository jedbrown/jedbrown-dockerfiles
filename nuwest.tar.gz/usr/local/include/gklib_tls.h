#ifndef metis__thread
#define metis__thread __thread
#endif
